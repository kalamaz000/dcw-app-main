#!/bin/bash

docker run -itd -p 80:3000 devopscloudweek3/dcw-app:develop